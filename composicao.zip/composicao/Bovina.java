package composicao;

public class Bovina {
	private int idBovina;
	private Carne carne;
	
	public int getIdBovina() {
		return idBovina;
	}
	public void setIdBovina(int idBovina) {
		this.idBovina = idBovina;
	}
	public Carne getCarne() {
		return carne;
	}
	public void setCarne(Carne carne) {
		this.carne = carne;
	}
	
	
	
}
