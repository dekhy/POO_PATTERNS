package composicao;

public class Aviaria {
	private int idAviaria;
	private Carne carne;
	
	
	
	public int getIdAviaria() {
		return idAviaria;
	}
	public void setIdAviaria(int idAviaria) {
		this.idAviaria = idAviaria;
	}
	public Carne getCarne() {
		return carne;
	}
	public void setCarne(Carne carne) {
		this.carne = carne;
	}
	
	

}
