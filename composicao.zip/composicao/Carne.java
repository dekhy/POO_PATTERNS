package composicao;

public class Carne {
	private int idCarne;
	private String nome;
	private double preco;
	
	
	public Carne(int idCarne, String nome, double preco) {
		this.idCarne = idCarne;
		this.nome = nome;
		this.preco = preco;
	}
	
	public int getIdCarne() {
		return idCarne;
	}
	public void setIdCarne(int idCarne) {
		this.idCarne = idCarne;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	
	
	
	
}
