package composicao;

public class Tester {
	public static void main(String[] args) {

		Carne carne1 = new Carne(10, "AVIARIA", 32);

		Aviaria bird = new Aviaria();
		bird.setIdAviaria(12);
		bird.setCarne(carne1);

		System.out.println(bird.getCarne().getNome());
		
		Carne carne2 = new Carne(10, "Bovina", 32);
		Bovina bird1 = new Bovina();
		bird1.setIdBovina(12);
		bird1.setCarne(carne2);
		
		System.out.println(bird1.getCarne().getNome());
		
		
	}

}
