package strategy;

public class Barulho {

}
