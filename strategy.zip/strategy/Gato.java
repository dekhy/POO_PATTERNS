package strategy;

public class Gato extends Animal{

	public Gato(String nome, int idade) {
		super(nome, idade);
	}
	
	public void fazerBarulho() {
		System.out.println("Miau");
	}
}
