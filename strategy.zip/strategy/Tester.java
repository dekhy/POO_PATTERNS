package strategy;

public class Tester {

	public static void main(String[] args) {
		
		Animal gato1 = new Gato("Ximbinha", 20);
		Animal cachorro1 = new Cachorro("Joelma", 20);
		gato1.fazerBarulho();
		cachorro1.fazerBarulho();
	}
}
